
CREATE PROCEDURE AddCustomerToRoom
(
    @SDT NVARCHAR(15),
    @SoPhong INT,
    @Result NVARCHAR(255) OUTPUT
)
AS
BEGIN
    DECLARE @MaKH INT;

    -- Lấy mã khách hàng dựa trên số điện thoại
    SELECT @MaKH = MaKH
    FROM KHACHHANG
    WHERE SDT = @SDT;

    -- Kiểm tra nếu mã khách hàng không tìm thấy
    IF @MaKH IS NULL
    BEGIN
        SET @Result = 'Khách hàng không tồn tại';
        RETURN;
    END

    -- Cập nhật mã khách hàng vào bảng PHONG
    UPDATE PHONG
    SET MaKH = @MaKH
    WHERE SoPhong = @SoPhong;

    -- Thay đổi trạng thái phòng thành "sudung"
    UPDATE PHONG
    SET TinhTrang = 'sudung'
    WHERE SoPhong = @SoPhong;

    SET @Result = 'Đã thêm khách hàng vào phòng thành công';
END;
go

