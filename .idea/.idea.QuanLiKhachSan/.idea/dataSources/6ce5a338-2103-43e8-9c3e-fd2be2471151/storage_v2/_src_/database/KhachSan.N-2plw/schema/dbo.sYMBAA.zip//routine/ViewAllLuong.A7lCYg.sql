
-- Thủ tục để xem lương của một nhân viên cụ thể dựa trên mã nhân viên
-- Thủ tục để xem lương của tất cả nhân viên
CREATE PROCEDURE ViewAllLuong
AS
BEGIN
    SELECT 
        nv.MaNV,
        nv.HoTen,
        l.LuongCB,
        l.PhuCap,
        l.Thuong,
        (l.LuongCB + l.PhuCap + l.Thuong) AS TongLuong
    FROM 
        LUONG l
    JOIN 
        NHANVIEN nv ON l.MaNV = nv.MaNV;
END;
go

