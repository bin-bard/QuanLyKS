
CREATE PROCEDURE ThanhToanHoaDon
    @SDT NVARCHAR(15),  -- Thêm SDT của KHACHHANG làm đầu vào
    @MaNV INT
AS
BEGIN
    DECLARE @MaHoaDon INT;

    -- Tìm mã hóa đơn từ số điện thoại khách hàng
    SELECT TOP 1 @MaHoaDon = hd.MaHoaDon
    FROM HOADON hd
    JOIN KHACHHANG kh ON hd.MaKH = kh.MaKH
    WHERE kh.SDT = @SDT AND hd.TrangThai = 'chua-thanh-toan'
    ORDER BY hd.NgayNhanPhong;  -- Ưu tiên hóa đơn gần nhất nếu có nhiều hóa đơn chưa thanh toán

    -- Nếu tìm thấy hóa đơn, cập nhật thông tin
    IF @MaHoaDon IS NOT NULL
    BEGIN
        UPDATE HOADON
        SET TrangThai = 'da-thanh-toan',
            NgayTraPhong = GETDATE(),
            MaNV = @MaNV
        WHERE MaHoaDon = @MaHoaDon;
    END
    ELSE
    BEGIN
        PRINT 'Không tìm thấy hóa đơn chưa thanh toán cho số điện thoại này.';
    END
END;
go

