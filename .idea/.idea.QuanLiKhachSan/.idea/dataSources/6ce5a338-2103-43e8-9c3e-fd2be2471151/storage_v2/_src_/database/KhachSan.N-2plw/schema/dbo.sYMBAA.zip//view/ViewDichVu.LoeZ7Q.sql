
CREATE VIEW ViewDichVu AS
SELECT MaDichVu,MaHoaDon, TenDichVu, MoTa, Gia
FROM DICHVU;
go

