
CREATE PROCEDURE AddRoom
    @SoPhong NVARCHAR(50),
    @TenLoaiPhong NVARCHAR(50),
    @LoaiGiuong NVARCHAR(50),
    @Gia DECIMAL(18, 2),
    @MaKhachSan INT,
    @TinhTrang NVARCHAR(50) = 'trong'
AS
BEGIN
    INSERT INTO PHONG(SoPhong, TenLoaiPhong, LoaiGiuong, Gia, MaKhachSan, TinhTrang)
    VALUES (@SoPhong, @TenLoaiPhong, @LoaiGiuong, @Gia, @MaKhachSan, @TinhTrang)
END
go

