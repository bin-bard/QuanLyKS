
CREATE TRIGGER trg_UpdateRoomStatusAfterPayment
ON HOADON
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra nếu có sự thay đổi trong trạng thái hóa đơn
    IF UPDATE(TrangThai)
    BEGIN
        DECLARE @MaKH INT;
        DECLARE @MaPhong INT;

        -- Lấy mã khách hàng từ hóa đơn đã cập nhật
        SELECT @MaKH = inserted.MaKH
        FROM inserted
        WHERE TrangThai = 'da-thanh-toan';

        -- Nếu khách hàng đã thanh toán thì cập nhật trạng thái phòng
        IF @MaKH IS NOT NULL
        BEGIN
            -- Lấy mã phòng của khách hàng
            SELECT @MaPhong = MaPhong
            FROM PHONG
            WHERE MaKH = @MaKH;

            -- Cập nhật trạng thái phòng thành 'trong'
            UPDATE PHONG
            SET TinhTrang = 'trong',
                MaKH = NULL
            WHERE MaPhong = @MaPhong;
        END
    END
END;
go

