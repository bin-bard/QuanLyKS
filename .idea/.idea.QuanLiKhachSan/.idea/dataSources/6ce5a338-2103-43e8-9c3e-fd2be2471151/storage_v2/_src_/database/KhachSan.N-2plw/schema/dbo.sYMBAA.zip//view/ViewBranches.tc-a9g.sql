
-- Create view to see all branches
CREATE VIEW ViewBranches AS
SELECT MaKhachSan, Ten, DiaChi, SDT, Email
FROM KHACHSAN;
go

