
CREATE PROCEDURE AddDichVu
    @TenDichVu NVARCHAR(100),
    @MoTa NVARCHAR(255),
    @Gia DECIMAL(10, 2)
AS
BEGIN
    INSERT INTO DICHVU ( TenDichVu, MoTa, Gia)
    VALUES (@TenDichVu, @MoTa, @Gia);
END
go

