
--Transaction
CREATE PROCEDURE DeleteEmployee
    @MaNV INT
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        -- Bắt đầu Transaction
        BEGIN TRANSACTION;

        -- Xóa các bản ghi liên quan trong bảng KHUYENMAI (hoặc các bảng khác có khóa ngoại đến NHANVIEN)
        DELETE FROM KHUYENMAI
        WHERE MaNV = @MaNV;

        -- Xóa tài khoản liên quan đến nhân viên
        DELETE FROM TAIKHOAN 
        WHERE MaNV = @MaNV;

        -- Xóa nhân viên từ bảng NHANVIEN
        DELETE FROM NHANVIEN 
        WHERE MaNV = @MaNV;

        -- Cam kết Transaction
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        -- Nếu có lỗi xảy ra, rollback transaction
        ROLLBACK TRANSACTION;

        -- Trả về thông báo lỗi
        DECLARE @ErrorMessage NVARCHAR(4000);
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH
END;
go

