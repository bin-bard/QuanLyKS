
CREATE VIEW ViewRooms AS
SELECT r.SoPhong, r.TenLoaiPhong, r.LoaiGiuong, r.Gia, r.TinhTrang, b.Ten AS BranchName
FROM PHONG r
JOIN KHACHSAN b ON r.MaKhachSan = b.MaKhachSan;
go

