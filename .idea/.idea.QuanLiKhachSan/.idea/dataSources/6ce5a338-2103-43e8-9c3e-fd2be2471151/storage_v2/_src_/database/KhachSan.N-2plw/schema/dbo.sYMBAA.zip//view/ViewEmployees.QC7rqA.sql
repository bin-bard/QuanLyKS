

CREATE VIEW ViewEmployees AS
SELECT 
    MaNV,
    HoTen,
    GioiTinh,
    NgaySinh,
    SDT,
    Email,
    DiaChi,
    QueQuan,
    ChucVu
FROM 
    NHANVIEN;
go

