
CREATE FUNCTION GetAvailableDichVu
(
    @TenDichVu NVARCHAR(100)
)
RETURNS TABLE
AS
RETURN
(
    SELECT TenDichVu, MoTa
    FROM DICHVU
    WHERE TenDichVu = @TenDichVu
);
go

