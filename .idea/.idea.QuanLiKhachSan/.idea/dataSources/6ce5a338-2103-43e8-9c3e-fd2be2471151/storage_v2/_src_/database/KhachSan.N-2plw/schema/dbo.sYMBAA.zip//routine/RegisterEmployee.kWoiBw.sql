
-- Transaction
CREATE PROCEDURE RegisterEmployee
    @HoTen NVARCHAR(100),
    @GioiTinh NVARCHAR(10),
    @NgaySinh DATE,
    @SDT NVARCHAR(15),
    @Email NVARCHAR(100),
    @DiaChi NVARCHAR(255),
    @QueQuan NVARCHAR(100),
    @ChucVu NVARCHAR(50),
    @TenDangNhap NVARCHAR(50),
    @MatKhau NVARCHAR(255)
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        -- Bắt đầu Transaction
        BEGIN TRANSACTION;

        DECLARE @MaNV INT;

        -- Thêm nhân viên vào bảng NHANVIEN
        INSERT INTO NHANVIEN (HoTen, GioiTinh, NgaySinh, SDT, Email, DiaChi, QueQuan, ChucVu)
        VALUES (@HoTen, @GioiTinh, @NgaySinh, @SDT, @Email, @DiaChi, @QueQuan, @ChucVu);
        
        -- Lấy mã nhân viên vừa thêm
        SET @MaNV = SCOPE_IDENTITY();

        -- Thêm tài khoản vào bảng TAIKHOAN
        INSERT INTO TAIKHOAN (TenDangNhap, MaNV, MatKhau)
        VALUES (@TenDangNhap, @MaNV, @MatKhau);
        
        -- Cam kết Transaction
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        -- Nếu có lỗi xảy ra, rollback transaction
        ROLLBACK TRANSACTION;

        -- Trả về thông báo lỗi
        DECLARE @ErrorMessage NVARCHAR(4000);
        SET @ErrorMessage = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH
END;
go

