
CREATE FUNCTION GetAvailableRoomsByCriteria
(
    @TenLoaiPhong NVARCHAR(100),
    @LoaiGiuong NVARCHAR(100)
)
RETURNS TABLE
AS
RETURN
(
    SELECT SoPhong, Gia
    FROM PHONG
    WHERE TinhTrang = 'trong' AND TenLoaiPhong = @TenLoaiPhong AND LoaiGiuong = @LoaiGiuong
);
go

