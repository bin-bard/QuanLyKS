
CREATE PROCEDURE AddKhuyenMai
    @MaNV INT = NULL,
    @TenKhuyenMai NVARCHAR(100),
    @PhanTramGiam DECIMAL(5, 2),
    @NgayBatDau DATE,
    @NgayKetThuc DATE
AS
BEGIN
    INSERT INTO KHUYENMAI (MaNV, TenKhuyenMai, PhanTramGiam, NgayBatDau, NgayKetThuc)
    VALUES (@MaNV, @TenKhuyenMai, @PhanTramGiam, @NgayBatDau, @NgayKetThuc);
END
go

