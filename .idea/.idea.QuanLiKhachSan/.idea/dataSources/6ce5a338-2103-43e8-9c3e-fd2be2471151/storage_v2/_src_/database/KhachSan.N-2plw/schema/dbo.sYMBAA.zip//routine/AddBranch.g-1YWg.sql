
-- Create stored procedure to add a branch
CREATE PROCEDURE AddBranch
    @Ten NVARCHAR(100),
    @DiaChi NVARCHAR(255),
    @SDT NVARCHAR(15),
    @Email NVARCHAR(100)
AS
BEGIN
    INSERT INTO KHACHSAN (Ten, DiaChi, SDT, Email)
    VALUES (@Ten, @DiaChi, @SDT, @Email);
END;
go

