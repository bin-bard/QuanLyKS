

CREATE TRIGGER trg_UpdateRoomStatus
ON PHONG
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra nếu có sự thay đổi trong MaKH
    IF UPDATE(MaKH)
    BEGIN
        -- Cập nhật trạng thái phòng thành "sudung" nếu MaKH không NULL
        UPDATE PHONG
        SET TinhTrang = 'sudung'
        WHERE MaKH IS NOT NULL AND TinhTrang = 'trong';

        DECLARE @MaKH INT, @MaPhong INT, @MaHoaDon INT, @NgayNhanPhong DATETIME, @TongTien DECIMAL(10, 2);

        -- Lấy thông tin mã khách hàng và mã phòng đã cập nhật
        SELECT @MaKH = inserted.MaKH, @MaPhong = inserted.MaPhong
        FROM inserted;

        -- Lấy ngày nhận phòng hiện tại
        SET @NgayNhanPhong = GETDATE();

        -- Lấy giá phòng để tính tổng tiền (giả sử phòng được tính theo giá của bảng PHONG)
        SELECT @TongTien = Gia FROM PHONG WHERE MaPhong = @MaPhong;

        -- Tạo hóa đơn mới
        INSERT INTO HOADON (MaKH, NgayNhanPhong, TongTien, TrangThai)
        VALUES (@MaKH, @NgayNhanPhong, @TongTien, 'chua-thanh-toan');
    END
END;
go

