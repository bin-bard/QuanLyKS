
CREATE PROCEDURE AddServiceToCustomer
    @SDT NVARCHAR(15),
    @TenDichVu NVARCHAR(100),
    @MoTa NVARCHAR(255),
    @SoLuong INT
AS
BEGIN
    DECLARE @MaKH INT;
    DECLARE @MaDichVu INT;
    DECLARE @Gia DECIMAL(10, 2);
    DECLARE @TongTien DECIMAL(10, 2);

    -- Lấy mã khách hàng dựa trên số điện thoại
    SELECT @MaKH = MaKH
    FROM KHACHHANG
    WHERE SDT = @SDT;


    -- Kiểm tra nếu mã khách hàng không tìm thấy
    IF @MaKH IS NULL
    BEGIN
        RAISERROR('Khách hàng không tồn tại', 16, 1);
        RETURN;
    END

    -- Lấy mã dịch vụ và giá dịch vụ từ bảng DICHVU
    SELECT @MaDichVu = MaDichVu, @Gia = Gia
    FROM DICHVU
    WHERE TenDichVu = @TenDichVu;

    -- Kiểm tra nếu dịch vụ không tồn tại
    IF @MaDichVu IS NULL
    BEGIN
        RAISERROR('Dịch vụ không tồn tại', 16, 1);
        RETURN;
    END

    -- Tính tổng tiền
    SET @TongTien = @Gia * @SoLuong;

    -- Thêm vào bảng SUDUNG
    INSERT INTO SUDUNG (MaDichVu, MaKH, SoLuong, TongTienDV)
    VALUES (@MaDichVu, @MaKH, @SoLuong, @TongTien);
END;
go

