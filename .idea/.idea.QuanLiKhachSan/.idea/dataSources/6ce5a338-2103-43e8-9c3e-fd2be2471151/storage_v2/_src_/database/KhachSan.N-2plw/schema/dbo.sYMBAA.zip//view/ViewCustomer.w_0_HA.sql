
CREATE VIEW ViewCustomer AS
SELECT 
    MaKH, Ten, NgaySinh, DiaChi,SDT, Email
FROM KHACHHANG;
go

