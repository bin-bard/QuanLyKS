

CREATE VIEW ViewKhuyenMai AS
SELECT MaKM, MaNV, TenKhuyenMai, PhanTramGiam, NgayBatDau, NgayKetThuc
FROM KHUYENMAI;
go

