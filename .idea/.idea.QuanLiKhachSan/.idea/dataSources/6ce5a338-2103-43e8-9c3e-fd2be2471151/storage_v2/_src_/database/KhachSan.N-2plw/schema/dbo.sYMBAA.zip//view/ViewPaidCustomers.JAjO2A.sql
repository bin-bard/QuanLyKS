

CREATE VIEW ViewPaidCustomers AS
SELECT 
    h.MaHoaDon,
    k.Ten AS TenKhachHang,
    h.NgayNhanPhong,
    h.NgayTraPhong,
    SUM(ISNULL(d.Gia, 0) * ISNULL(sd.SoLuong, 0)) AS TongTienDichVu,
    h.TongTien AS TongTienPhong,
    ISNULL(km.PhanTramGiam, 0) AS PhanTramGiam,
    (h.TongTien + SUM(ISNULL(d.Gia, 0) * ISNULL(sd.SoLuong, 0))) * (1 - ISNULL(km.PhanTramGiam, 0) / 100) AS TongTienSauKM,
    h.TrangThai
FROM 
    HOADON h
    JOIN KHACHHANG k ON h.MaKH = k.MaKH
    LEFT JOIN SUDUNG sd ON sd.MaKH = k.MaKH
    LEFT JOIN DICHVU d ON sd.MaDichVu = d.MaDichVu
    LEFT JOIN KHUYENMAI km ON km.MaNV = h.MaNV
WHERE 
    h.TrangThai = 'da-thanh-toan'
GROUP BY 
    h.MaHoaDon, k.Ten, h.NgayNhanPhong, h.NgayTraPhong, h.TongTien, km.PhanTramGiam, h.TrangThai;
go

