

CREATE PROCEDURE AddCustomer
    @Ten NVARCHAR(100),
    @NgaySinh DATE,
    @DiaChi NVARCHAR(255),
    @SDT NVARCHAR(15),
    @Email NVARCHAR(100)
AS
BEGIN
    INSERT INTO KHACHHANG (Ten, NgaySinh, DiaChi, SDT, Email)
    VALUES (@Ten, @NgaySinh, @DiaChi, @SDT, @Email);
END;
go

