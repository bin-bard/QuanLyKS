

CREATE VIEW KhachDangSuDungPhong AS
SELECT 
    k.MaKH,
    k.Ten AS TenKhachHang,
    p.SoPhong,
    p.TenLoaiPhong,      
    p.Gia,      
    p.TinhTrang,      
    p.LoaiGiuong             
FROM 
    KHACHHANG k
JOIN 
    PHONG p ON k.MaKH = p.MaKH 
WHERE 
    p.TinhTrang = 'sudung'; 
go

